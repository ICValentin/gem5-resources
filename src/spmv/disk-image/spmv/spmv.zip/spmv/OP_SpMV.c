/* OP SpMV for gem5 simulation */

#include <stdlib.h>
#include <stdio.h>

#include "__A_MATRIX_HEADER__.h"

int main(int argc, char *argv[]) {
    int j, pos;

    printf("Start OP SpMV.\n");

    for (j = 0; j < N; j++) {
        for (pos = ptr_csc[j]; pos < ptr_csc[j+1]; pos++) {
            y[idx_csc[pos]] += val_csc[pos]*x[j];
        }
    }

    printf("End.\n");
    printf("y[20] = %f\n", *(y+20));

    return 0;
}
