/* IP SpMV for gem5 simulation */

#include <stdlib.h>
#include <stdio.h>

#include "__A_MATRIX_HEADER__.h"

int main(int argc, char *argv[]) {
    int i, pos;

    printf("Start OP SpMV.\n");

    for (i = 0; i < M; i++) {
        for (pos = ptr_csr[i]; pos < ptr_csr[i+1]; pos++) {
            y[i] += val_csr[pos]*x[idx_csr[pos]];
        }
    }

    printf("End.\n");
    printf("y[20] = %f\n", *(y+20));

    return 0;
}
